const Content = () => {
  console.log("content");
  return <div>content</div>;
};

export default Content;
