import React from "react";

const BestSeller = () => {
  return (
    <div>
      <h1>Best seller</h1>
    </div>
  );
};

export default BestSeller;
