import React from "react";

const Carousel = () => {
  return (
    <div>
      <h1>Carousel</h1>
    </div>
  );
};

export default Carousel;
