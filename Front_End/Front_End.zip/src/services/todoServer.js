import { client } from "../utils/httpUtils";

export const getTodo = async () => {
  return await client.get("/todos");
};
